module.exports = {
    url: 'mongodb+srv://students:students123@cluster0-dtfjl.mongodb.net/student-Project?retryWrites=true&w=majority'
}
