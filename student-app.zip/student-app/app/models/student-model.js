const mongoose = require('mongoose');

const StudentSchema = mongoose.Schema({
    id: Number,
    name: String,
    department: String,
    regulation: String,
    contactNo: String,
    lectures: String,
    
}, {
    timestamps: true
});

module.exports = mongoose.model('Students', StudentSchema);